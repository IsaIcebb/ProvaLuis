import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import * as LocalAuthentication from 'expo-local-authentication';
import { useState, useEffect } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet
} from 'react-native';

import Login from './components/Login';
import Cadastro from './components/Cadastro';
import Inicio from './components/Inicio';

import { initDB } from './database';

const Stack = createNativeStackNavigator();

export default function App() {
  const [status, setStatus] = useState('');
  const [autenticado, setAutenticado] = useState(false);

  useEffect(() => {
    initDB();
  }, []);

  const handleAuth = async () => {
    const hasHardware =
      await LocalAuthentication.hasHardwareAsync();

    if (!hasHardware) {
      setStatus('Dispositivo não suporta biometria.');
      return;
    }

    const isEnrolled =
      await LocalAuthentication.isEnrolledAsync();

    if (!isEnrolled) {
      setStatus('Nenhuma biometria cadastrada.');
      return;
    }

    const result =
      await LocalAuthentication.authenticateAsync({
        promptMessage:
          'Autentique-se para continuar',
        fallbackLabel: 'Usar senha',
        disableDeviceFallback: false,
      });

    if (result.success) {
      setStatus('✅ Autenticado com sucesso!');
      setAutenticado(true);
    } else {
      setStatus(`❌ Erro: ${result.error}`);
    }
  };

  if (!autenticado) {
    return (
      <View style={styles.centralizar}>
        <Text style={styles.textoStatus}>
          {status}
        </Text>

        <Button
          title="Autenticar"
          onPress={handleAuth}
        />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen
          name="Login"
          component={Login}
        />

        <Stack.Screen
          name="Cadastro"
          component={Cadastro}
        />

        <Stack.Screen
          name="Inicio"
          component={Inicio}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  centralizar: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  textoStatus: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
});