import { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import Estilos from '../styles/estilos';
import { cadastrarUsuario } from '../database';
import { TouchableOpacity } from 'react-native';

export default function Cadastro({ navigation }) {
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function handleCadastro() {
    if (!nome.trim() || !sobrenome.trim() || !email.trim() || !senha.trim()) {
      Alert.alert("Erro", "Preencha todos os campos");
      return;
    }

    try {
      await cadastrarUsuario(nome, sobrenome, email, senha);
      Alert.alert("Sucesso", "Conta criada!");

      navigation.navigate("Login"); 
      
    } catch {
      Alert.alert("Erro", "Este email já está cadastrado");
    }
  }

  return (
    <View style={Estilos.containerLogin}>
      <Text style={Estilos.textoTitulo}>Criar Conta</Text>

      <TextInput
        placeholder="Nome"
        style={Estilos.campoTexto}
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        placeholder="Sobrenome"
        style={Estilos.campoTexto}
        value={sobrenome}
        onChangeText={setSobrenome}
      />

      <TextInput
        placeholder="Email"
        style={Estilos.campoTexto}
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        placeholder="Senha"
        secureTextEntry
        style={Estilos.campoTexto}
        value={senha}
        onChangeText={setSenha}
      />

     <TouchableOpacity
        style={[Estilos.b, { backgroundColor: '#400662', marginBottom: 10 }]}
        onPress={handleCadastro}
      >
        <Text style={{ color: 'white', textAlign: 'center', padding: 10 }}>Cadastrar</Text>
      </TouchableOpacity>
    </View>
  );
}
