import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import Estilos from '../styles/estilos';
import { loginUsuario } from '../database';

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function handleLogin() {
    const usuario = await loginUsuario(email, senha);

    if (!usuario) {
      Alert.alert("Erro", "Email ou senha incorretos.");
      return;
    }

    navigation.replace("Inicio", { usuario });
  }
  return (
    <View style={Estilos.containerLogin}>
      <Text style={Estilos.textoTitulo}>Login</Text>

      <TextInput
        placeholder="Email"
        style={Estilos.campoTexto}
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        placeholder="Senha"
        secureTextEntry
        style={Estilos.campoTexto}
        value={senha}
        onChangeText={setSenha}
      />

      <TouchableOpacity
        style={[Estilos.b, { backgroundColor: '#400662', marginBottom: 10 }]}
        onPress={handleLogin}
      >
        <Text style={{ color: 'white', textAlign: 'center', padding: 10 }}>Entrar</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={{ backgroundColor: 'yellow' }}
        onPress={() => navigation.navigate("Cadastro")}
      >
        <Text style={{ color: 'white', textAlign: 'center', padding: 10,  backgroundColor: '#400662' }}>Criar Conta</Text>
      </TouchableOpacity>
    </View>
  );
}